public class MathOperations {
    public static void main(String[] args) {
        
        int a = 10;
        int b = 5;

        System.out.println("Arithmetic Operators");
        System.out.println("Addition: " + (a + b));
        System.out.println("Subtraction: " + (a - b));
        System.out.println("Multiplication: " + (a * b));
        System.out.println("Division: " + (a / b));
        System.out.println("Modulus: " + (a % b));
        
        int x = 5;
        System.out.println("\nUnary Operators");
        System.out.println("Original x: " + x);
        System.out.println("Pre-increment (++x): " + (++x));
        System.out.println("Post-increment (x++): " + (x++));
        System.out.println("After Post-increment x: " + x);
        
        int y = 10;
        System.out.println("\nAssignment Operators");
        y += 5; 
        System.out.println("y += 5: " + y);
        y -= 3; 
        System.out.println("y -= 3: " + y);
        y *= 2;
        System.out.println("y *= 2: " + y);
        y /= 4;
        System.out.println("y /= 4: " + y);
        y %= 3;
        System.out.println("y %= 3: " + y);

        int m = 8;
        int n = 12;

        System.out.println("\nRelational Operators");
        System.out.println("m == n: " + (m == n));
        System.out.println("m != n: " + (m != n));
        System.out.println("m > n: " + (m > n));
        System.out.println("m < n: " + (m < n));
        System.out.println("m >= n: " + (m >= n));
        System.out.println("m <= n: " + (m <= n));

        boolean condition1 = true;
        boolean condition2 = false;

        System.out.println("\nLogical Operators");
        System.out.println("condition1 && condition2: " + (condition1 && condition2));
        System.out.println("condition1 || condition2: " + (condition1 || condition2));
        System.out.println("!condition1: " + (!condition1));

        int score = 75;

        System.out.println("\nTernary Operator");
        String result = (score >= 40) ? "Pass" : "Fail";
        System.out.println("Score: " + score);
        System.out.println("Result: " + result);
    }
}