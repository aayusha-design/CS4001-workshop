public class DefaultValues {

    byte myByte;
    short myShort;
    int myInt;
    long myLong;
    float myFloat;
    double myDouble;
    char myChar;
    boolean myBoolean;

    public static void main(String[] args) {

        DefaultValues obj = new DefaultValues();

        System.out.println("Default Values of Java Primitive Types:");

        System.out.println("byte: " + obj.myByte);
        System.out.println("short: " + obj.myShort);
        System.out.println("int: " + obj.myInt);
        System.out.println("long: " + obj.myLong);
        System.out.println("float: " + obj.myFloat);
        System.out.println("double: " + obj.myDouble);
        System.out.println("char: " + obj.myChar);
        System.out.println("boolean: " + obj.myBoolean);
    }
}

