public class LiteralPractice {
    public static void main(String[] args) {

        // Long literal (requires 'L' suffix)
        long largeNumber = 1234567890123L;

        // Float literal (requires 'f' suffix)
        float decimalNumber = 12.34f;

        // Char literal using Unicode escape sequence for copyright symbol ©
        char copyrightSymbol = '\u00A9';

        // Print the values
        System.out.println("Long value: " + largeNumber);
        System.out.println("Float value: " + decimalNumber);
        System.out.println("Char value (Unicode): " + copyrightSymbol);
    }
}