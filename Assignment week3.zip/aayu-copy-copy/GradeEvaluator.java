import java.util.Scanner;

public class GradeEvaluator {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int grade;
        String result;
        System.out.print("Enter your grade: ");
        grade = input.nextInt();
        result = (grade >= 40) ? "Pass" : "Fail";
        System.out.println("\n----- Grade Evaluation -----");
        System.out.println("Grade:\t" + grade);
        System.out.println("Result:\t" + result);
        System.out.println("----------------------------");
    }
}